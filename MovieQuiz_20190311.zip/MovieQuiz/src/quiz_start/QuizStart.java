package quiz_start;

import quiz_choice.Choice;

public class QuizStart {

	public static void main(String[] args) {

		Choice choice = new Choice();
		choice.quizChoice();


	}

}