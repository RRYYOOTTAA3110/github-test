package quiz_type;

import QuizInterface.WordInterface;
import making.judgment;

/*
 * クイズ1のクラス
 */

public class Quiz3 extends QuizFormat implements WordInterface {

	//問題文のリスト
	private String qList[] = {tsQuiz1, tsQuiz2, tsQuiz3, tsQuiz4};
	//4択のリスト
	private String selectList[] = {tsSelect1, tsSelect2, tsSelect3, tsSelect4};
	//正解リスト
	private String rightList[] = {d, c, a, b};

	//判定クラスのインスタンス
	judgment juge = new judgment();

	//正解後のセリフ
	protected void Trivia(int tNum){

		switch(tNum){
		case 0:
			enter.println(tsTrivia1);
			enter.sleep(3000);
			enter.println(next);
			enter.println("\n");
			break;
		case 1:
			enter.println(tsTrivia2_1);
			enter.sleep(4000);
			enter.println(tsTrivia2_2);
			enter.sleep(3000);
			enter.println(next);
			enter.println("\n");
			break;
		case 2:
			enter.println(tsTrivia3_1);
			enter.sleep(5000);
			enter.println(tsTrivia3_2);
			enter.sleep(3000);
			enter.println(last);
			break;
		case 3:
			enter.println(congrats);
			enter.sleep(2000);
			enter.println(tsTrivia4_1);
			enter.sleep(4000);
			enter.println(tsTrivia4_2);
			enter.sleep(3000);
			enter.println(tsTrivia4_3);
			enter.sleep(5000);
			enter.println(tsTrivia4_4);
			enter.sleep(4000);
			enter.println(tsTrivia4_5);
			break;
		}

	}

	//不正解後のセリフ
	protected void missAns(int mNum){

		if (mNum == 0 || mNum == 1 || mNum == 2){
			enter.println(retry);
		} else if (mNum == 3) {
			enter.println(fail);
		}

	}

	//クイズ
	public void quiz(){

		for (int i = 0; i < 4; i ++){

			point: while (true){
				enter.sleep(1000);
				enter.println(qList[i]);
				enter.sleep(1000);
				enter.println(selectList[i]);

				//回答の入力
				String ans = enter.readLine();

				try {
					//回答の評価
					juge.setAnsCheck(ans, rightList[i]);
				} catch (judgment e) {
					enter.println(improperAns);
					continue point;
				}

				//結果の取得
				int valu = juge.getAnsCheck();

				//結果の表示
				if (valu == 1) {
					enter.println(rightAns);
					enter.sleep(1000);
					Trivia(i);
					break;
				} else {
					enter.println(missAns);
					enter.sleep(1000);
					missAns(i);
					if (i < 3){
						continue point;
					} else {
						break;
					}
				}
			}

		}


	}






}
