package quiz_type;

import QuizInterface.WordInterface;
import making.judgment;

/*
 * クイズ2のクラス
 */

public class Quiz2 extends QuizFormat implements WordInterface {

	//問題文のリスト
	private String qList[] = {fgQuiz1, fgQuiz2, fgQuiz3, fgQuiz4};
	//4択のリスト
	private String selectList[] = {fgSelect1, fgSelect2, fgSelect3, fgSelect4};
	//正解リスト
	private String rightList[] = {b, b, a, d};

	//判定クラスのインスタンス
	judgment juge = new judgment();

	//正解後のセリフ
	protected void Trivia(int tNum){

		switch(tNum){
		case 0:
			enter.println(fgTrivia1);
			enter.sleep(5000);
			enter.println(next);
			enter.println("\n");
			break;
		case 1:
			enter.println(fgTrivia2);
			enter.sleep(3000);
			enter.println(next);
			enter.println("\n");
			break;
		case 2:
			enter.println(fgTrivia3_1);
			enter.sleep(5000);
			enter.println(fgTrivia3_2);
			enter.sleep(3000);
			enter.println(last);
			break;
		case 3:
			enter.println(congrats);
			enter.sleep(2000);
			enter.println(fgTrivia4_1);
			enter.sleep(4000);
			enter.println(fgTrivia4_2);
			enter.sleep(3000);
			enter.println(fgTrivia4_3);
			break;
		}

	}

	//不正解後のセリフ
	protected void missAns(int mNum){

		if (mNum == 0 || mNum == 1 || mNum == 2){
			enter.println(retry);
		} else if (mNum == 3) {
			enter.println(fail);
		}

	}

	//クイズ
	public void quiz(){

		for (int i = 0; i < 4; i ++){

			point: while (true){
				enter.sleep(1000);
				enter.println(qList[i]);
				enter.sleep(1000);
				enter.println(selectList[i]);

				//回答の入力
				String ans = enter.readLine();

				try {
					//回答の評価
					juge.setAnsCheck(ans, rightList[i]);
				} catch (judgment e) {
					enter.println(improperAns);
					continue point;
				}

				//結果の取得
				int valu = juge.getAnsCheck();

				//結果の表示
				if (valu == 1) {
					enter.println(rightAns);
					enter.sleep(1000);
					Trivia(i);
					break;
				} else {
					enter.println(missAns);
					enter.sleep(1000);
					missAns(i);
					if (i < 3){
						continue point;
					} else {
						break;
					}
				}
			}

		}


	}






}
