package quiz_type;

import QuizInterface.JudgmentInterface;
import QuizInterface.WordInterface;

/*
 * クイズの抽象クラス
 */

public abstract class QuizFormat implements WordInterface, JudgmentInterface {

	//正解後のセリフ
	protected void Trivia(int tNum){
	}

	//不正解後のセリフ
	protected void missAns(int mNum){

	}


}
