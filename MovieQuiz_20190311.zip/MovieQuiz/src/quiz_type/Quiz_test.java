package quiz_type;

import QuizInterface.WordInterface;
import making.judgment;

/*
 * クイズのテスト用
 */

public class Quiz_test extends QuizFormat implements WordInterface {

	//判定クラスのインスタンス
	judgment juge = new judgment();

	public void quiz() {


		//第1問
		point: while (true){

			//問題の表示
			enter.sleep(1000);
			enter.println(smQuiz1);
			enter.sleep(1000);
			enter.println(spSelect1);

			//回答の入力
			String ans = enter.readLine();

			try {
				//回答の評価
				juge.setAnsCheck(ans, c);
			} catch (judgment e) {
				enter.println(improperAns);
				continue point;
			}
			//結果の取得
			int valu = juge.getAnsCheck();

			//結果の表示
			if (valu == 1) {
				enter.println(rightAns);
				enter.sleep(1000);
				enter.println(smTrivia1);
				enter.sleep(1000);
				enter.println(next);
				enter.println("\n");
				break;
			} else {
				enter.println(missAns);
				enter.sleep(1000);
				enter.println(retry);
				continue point;
			}

		}

		//第2問
		point: while (true){

			//問題の表示
			enter.sleep(3000);
			enter.println(smQuiz2);
			enter.sleep(1000);
			enter.println(spSelect2);

			//回答の入力
			String ans = enter.readLine();

			try {
				//回答の評価
				juge.setAnsCheck(ans, a);
			} catch (judgment e) {
				enter.println(improperAns);
				continue point;
			}
			//結果の取得
			int valu = juge.getAnsCheck();

			//結果の表示
			if (valu == 1) {
				enter.println(rightAns);
				enter.sleep(1000);
				enter.println(smTrivia2);
				enter.sleep(3000);
				enter.println(next);
				enter.println("\n");
				break;
			} else {
				enter.println(missAns);
				enter.sleep(1000);
				enter.println(retry);
				continue point;
			}

		}

		//第3問
		point: while (true){

			//問題の表示
			enter.sleep(3000);
			enter.println(smQuiz3);
			enter.sleep(1000);
			enter.println(spSelect3);

			//回答の入力
			String ans = enter.readLine();

			try {
				//回答の評価
				juge.setAnsCheck(ans, d);
			} catch (judgment e) {
				enter.println(improperAns);
				continue point;
			}
			//結果の取得
			int valu = juge.getAnsCheck();

			//結果の表示
			if (valu == 1) {
				enter.println(rightAns);
				enter.sleep(1000);
				enter.println(smTrivia3);
				enter.sleep(2000);
				enter.println(last);
				enter.println("\n");
				break;
			} else {
				enter.println(missAns);
				enter.sleep(1000);
				enter.println(retry);
				continue point;
			}

		}

		//第4問
		point: while (true){

			//問題の表示
			enter.sleep(3000);
			enter.println(smQuiz4);
			enter.sleep(1000);
			enter.println(spSelect4);

			//回答の入力
			String ans = enter.readLine();

			try {
				//回答の評価
				juge.setAnsCheck(ans, d);
			} catch (judgment e) {
				enter.println(improperAns);
				continue point;
			}
			//結果の取得
			int valu = juge.getAnsCheck();

			//結果の表示
			if (valu == 1) {
				enter.println(rightAns);
				enter.sleep(1000);
				enter.println(congrats);
				enter.sleep(2000);
				enter.println(smTrivia4_1);
				enter.sleep(4000);
				enter.println(smTrivia4_2);
				enter.sleep(3000);
				enter.println(smTrivia4_3);
				break;
			} else {
				enter.println(missAns);
				enter.sleep(1000);
				enter.println(fail);
				break;
			}

		}

	}


}
