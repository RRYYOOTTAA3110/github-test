package QuizInterface;

import making.judgment;

public interface JudgmentInterface {

	//判定インスタンス
	judgment juge = new judgment();

}
