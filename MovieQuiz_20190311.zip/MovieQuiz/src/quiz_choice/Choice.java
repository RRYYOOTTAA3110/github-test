package quiz_choice;

import QuizInterface.WordInterface;
import input_related.EnterOnConsole;
import ouiz_number.QuizNumber;

public class Choice implements WordInterface {

	public void quizChoice(){

		EnterOnConsole enter = new EnterOnConsole();

		//オープニングのセリフ
		enter.println(op1);
		EnterOnConsole.sleep(2000);
		enter.println(op2);
		EnterOnConsole.sleep(2000);
		enter.println(op3);
		EnterOnConsole.sleep(3000);
		enter.println(op4);
		EnterOnConsole.sleep(4000);
		enter.println(op5);
		EnterOnConsole.sleep(2000);
		enter.println(op6);
		EnterOnConsole.sleep(5000);
		enter.println(op7);

		QuizNumber number = new QuizNumber();

		int quizNumber = number.getQuizNumber();

		switch(quizNumber){
		case 0:
			quiz1.quiz();
			break;
		case 1:
			quiz2.quiz();
			break;
		case 2:
			quiz3.quiz();
			break;
		}

	}

}
