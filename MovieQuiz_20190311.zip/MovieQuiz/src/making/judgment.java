package making;

/*
 * 回答の判定を行う
 */

public class judgment extends Exception {

	//問題の判定を格納
	private int judge = 0;

	//回答の評価を格納
	public int getAnsCheck() {
		return judge;
	}

	//回答の評価
	public void setAnsCheck(String ans, String just) throws judgment{

	if(ans.equals(just)){
		judge = 1;
	} else if((ans.equals("a")) || (ans.equals("b")) || (ans.equals("c")) || (ans.equals("d"))){
		judge = 0;
	} else {
		judgment e = new judgment();
		//例外を送出
		throw e;
	}

}


}
